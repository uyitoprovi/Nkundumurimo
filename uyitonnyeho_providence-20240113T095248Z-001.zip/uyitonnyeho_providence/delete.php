<?php
include('conn.php');
$fid=$_GET['id'];
$delete2=mysqli_query($conn,"DELETE from export where food_id='$fid'");
if($delete2){
$delete=mysqli_query($conn,"DELETE From import where food_id='$fid'");
if($delete){
$delete1=mysqli_query($conn,"DELETE from food where food_id='$fid'");
if($delete1){
echo "delete";
header('location:view.php');
}else{
	echo "not deleted",$conn->error;
}
}
}
?>