<?php
session_start();
if(isset($_SESSION['user']))
{
}else
{
	header("location:home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;width: 1200px;height: 500px;">
<div class="well shadow sm-4 bg-dark rounded-0" style="background-color: #28a745;float: left;width: 500px;height: 500px;"><br><br>
<h1 style="font-family: Comic Sans MS;color: white;font-size: 35px;">Dukundumurimo Company Ltd</h1>
</div><br><br><br><br><br><br>
<a href="home.php" class="btn btn-outline-dark rounded-0" style="color:back;
width: 300px;font-family: Comic Sans MS;">HOME</a><br><br>
<a href="login.php" class="btn btn-outline-dark rounded-0" style="color: back;
width: 300px;font-family: Comic Sans MS;">LOGIN</a>
</div>
</form>
</div>
<div class="footer">
<p style="color:white;">copy&copyright2021</p>
</div>
</body>
</html>