<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><h1 style="color:white;font-family: Comic Sans MS;">DUKUNDE UMURIMO ONLINE SYSTEM</h1></center>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;width: 1200px;height: 300px;">
<div class="well shadow sm-4 bg-dark rounded-0" style="background-color: #28a745;float: left;width: 300px;height: 300px;"><br><br>
<a href="login.php" class="btn btn-outline-dark rounded-0" style="color: white;
width: 300px;font-family: Comic Sans MS;">LOGIN</a>
</div><br><br>
Welcome to our system dukundumurimo<br> company ltd which located in Muhanga district<br> southern province. this system help in <br> management of stock by importing and exporting<br> food like beans,rice,cassava flour,maize flour.
</form>
</div>
</body>
</html>