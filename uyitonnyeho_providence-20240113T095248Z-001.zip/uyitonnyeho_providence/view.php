<?php
session_start();
if(isset($_SESSION['user']))
{
}else
{
	header("location:home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;color:black;width: 1200px;height: 550px;float:right;">
<form method="POST" action="logout.php" class="form-group">
	<button type="submit" name="logout" class="btn btn-outline-dark" style="color: back;font-family: Comic Sans MS;">Logout</button></form>
<br><H1>FOOD STATUS</H1>
<br><table class="table table-stripped table-bordered" style="width:80%;">
	<tr>
		<th>food id</th>
		<th>food name</th>
		<th>food ownername</th>
		<th></th>
	</tr>
	<?php
	include('conn.php');
$select=mysqli_query($conn,"select * FROM food");
while ($row=mysqli_fetch_array($select)) {
	echo "<tr>
	<td>".$row['food_id']."</td>
<td>".$row['food_name']."</td>
<td>".$row['food_ownername']."</td>
<td><a href=\"import.php?id=".$row['food_id']."\">import</a></td>
<td><a href=\"delete.php?id=".$row['food_id']."\">delete</a></td>
<td><a href=\"update.php?id=".$row['food_id']."\">update</a></td>
	</tr>";
}
?>
	</table><a href="food.php">back</a><br><br>
	</div><br><br><br><br><br><br><br><br><br><br>
	<div class="footer"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<p style="color:white;">copy&copyright 2021</p>
</div>
	</div>
	</center>
