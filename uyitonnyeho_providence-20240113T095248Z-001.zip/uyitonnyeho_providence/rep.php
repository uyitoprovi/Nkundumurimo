<!DOCTYPE html>
<html>
<head>
	<title>Report</title>
</head>
<body>
	<center>
		<pre>
			<table border="1">
				<tr><th>importid</th>
					<th>foodid</th>
					<th>foodname</th>
					<th>importdate</th>
					<th>quantity</th>
				</tr>
				<?php
				include('conn.php');
$select=mysqli_query($conn,"SELECT i.importid,f.food_id,f.food_name,i.importdate,i.quantity 
	from import as i,food as f where i.food_id=f.food_id");
       $query=mysqli_query($conn,$select);
	            while($row=mysqli_fetch_array($query))
	            {
	            	echo 
	            	"
	            	   <tr>
                       <td>".$row['importid']."</td> 
                       <td>".$row['food_id']."</td>
                       <td>".$row['food_name']."</td>
                       <td>".$row['importdate']."</td>
                       <td>".$row['quantity']."</td>     
                       </tr>
	            	";
	            }

				?>
			</table>



		</pre>
	</center>

</body>
</html>
<?php 
include('conn.php');
if(isset($_POST['save']))
{
$select=mysqli_query($conn,"SELECT i.importid,f.food_id,f.food_name,i.importdate,i.quantity 
	from import as i,food as f where
		i.food_id=f.food_id");
$query1=mysqli_query($con,"$select");

require('fpdf/fpdf.php');
$pdf = new FPDF('p','mm','A4');
$pdf -> Addpage();                                                    					
$pdf -> setfont('Ariel','B',14);
$pdf -> cell(40,10,"importid",1,0,'c');
$pdf -> cell(40,10,"food_id,",1,0,'c');
$pdf -> cell(40,10,"foodname",1,0,'c');
$pdf -> cell(40,10,"importdate",1,0,'c');
$pdf -> cell(40,10,"quantity",1,1,'c');

$pdf -> setfont('Ariel','',14);
while($row = mysqli_fetch_array($query))
{
	$pdf ->cell(40,10,$row['importid'],1,0,'c');
	$pdf ->cell(40,10,$row['food_id'],1,0,'c');
	$pdf ->cell(40,10,$row['food_name'],1,0,'c');
	$pdf ->cell(40,10,$row['importdate'],1,0,'c');
	$pdf ->cell(40,10,$row['quantity'],1,0,'c');
}

$pdf->output();
}

?>