<?php
session_start();
if(isset($_SESSION['user']))
{
}else
{
	header("location:home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;color:black;width: 1200px;height: auto;float:right;">
<form method="POST" action="logout.php" class="form-group">
	<button type="submit" name="logout" class="btn btn-outline-dark" style="color:back;font-family: Comic Sans MS;">Logout</button></form>
	<form method="POST" action="food.php" class="form-group">
	<button type="submit" name="back" class="btn btn-outline-dark" style="color:back;font-family: Comic Sans MS;">BACK</button></form>

<br><H1>REPORT STATUS</H1>
<form method="post" action="#" style="border-bottom:10px green;">
<p>startdate</p>
	<input type="date" name="start" class="btn btn-outline-dark rounded-0" style="color: back;width: 500px;font-family: Comic Sans MS;"><br>
	<p>enddate</p>
	<input type="date" name="end" class="btn btn-outline-dark rounded-0" style="color: back;width: 500px;font-family: Comic Sans MS;"><br>
	<button type="submit" name="import" value="reportimport">reportimport</button>
	<button type="submit" name="export" value="reportexport">reportexport</button> 
</form>
<br><table class="table table-stripped table-bordered" style="width:80%;background-color:#dbecea;">
<h1>REPORT OF IMPORT</h1>
<tr>
<th>importid</th>
	<th>foodid</th>
	<th>foodname</th>
	<th>importdate</th>
	<th>quantity</th>
</tr>
</body>
</html>
<?php
include('conn.php');
if (isset($_POST['import'])) {
	$start=$_POST['start'];
	$end=$_POST['end'];
	$select=mysqli_query($conn,"SELECT *from import inner join food on 
		import.food_id=food.food_id where importdate between '$start' and '$end'");
	while ($row= mysqli_fetch_array($select)) {
		echo "<tr>
		<td>".$row['importid']."</td>
		<td>".$row['food_id']."</td>
		<td>".$row['food_name']."</td>
        <td>".$row['importdate']."</td>
        <td>".$row['quantity']."</td>
		</tr>";
	}
}
?>
</table><br><br>
	<br><table class="table table-stripped table-bordered" style="width:80%;background-color:#f3f3f3;">
	<h1>REPORT OF EXPORT</h1>
	<tr>
<th>exportid</th>
	<th>foodid</th>
	<th>foodname</th>
	<th>date</th>
	<th>quantity</th>
	<form method="post" action="">
	<input type="submit" name="save" value="report">
	</form>
</tr>

<?php
include('conn.php');
if (isset($_POST['export'])) {
	$start=$_POST['start'];
	$end=$_POST['end'];
	$select1=mysqli_query($conn,"SELECT * from export inner join food on 
		export.food_id=food.food_id where ExportDate between '$start' and '$end'");
	while ($row= mysqli_fetch_array($select1)) {
		echo "<tr>
		<td>".$row['E_Id']."</td>
		<td>".$row['food_id']."</td>
		<td>".$row['food_name']."</td>
        <td>".$row['ExportDate']."</td>
        <td>".$row['Quantity']."</td>
		</tr>";
	}
	}
	?>

	</table> 