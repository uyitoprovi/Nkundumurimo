<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;width: 1200px;height: 500px;">
<div class="well shadow sm-4 bg-dark rounded-0" style="background-color: #28a745;float: left;width: 300px;height: 500px;"><br><br>
<br><br><br><br><p style="color:white;">WELCOME TO NKUNDUMURIMO COMPANY LTD</p>
</div><br><br>
<form method="POST" action="#" class="form-group" style="width: 500px;">
<h1>MANAGER LOGIN</h1>
	<input type="text" name="user" class="form-control rounded-0" placeholder="enter username" 
	style="font-family: Comic Sans MS;" pattern="[a-z A-Z]*"><br>
	<input type="password" name="pass" class="form-control rounded-0" pattern="[0-9]{8}" 
	placeholder="enter password" style="font-family: Comic Sans MS;"><br>
	<button type="submit" name="login" class="btn btn-outline-dark rounded-0" style="color: back;width: 500px;font-family: Comic Sans MS;" value="login">LOGIN</button>
	<a href="home.php" style="float: left;color: BACK;">Back</a><br><br>
</form>
</div>
</body>
</html>
<?php
include("conn.php");
session_start();
if (isset($_POST['login'])) {
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$select=mysqli_query($conn,"SELECT * from manager where username='$user' and password='$pass'");
$row=mysqli_fetch_array($select);
$_SESSION['user']=$row['username'];
$_SESSION['pass']=$row['password'];
if ($_SESSION['user']==$user && $_SESSION['pass']==$pass) {
	echo'<script>alert("login successfully")</script>'.$user;
	header('location:food.php');
}
else{
	echo '<script>alert("login not successfully")</script>';
	}
}
?>