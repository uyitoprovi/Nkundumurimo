
<?php
include('conn.php');
$fid=$_GET['id'];
$select=mysqli_query($conn,"select *from food where food_id='$fid'");
$row=mysqli_fetch_array($select);
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;color:black;width: 1200px;height: 500px;float:right;">
<form method="POST" action="#" class="form-group">
	<button type="submit" name="logout" class="btn btn-outline-dark" style="color: back;font-family: Comic Sans MS;">Logout</button></form>

<form method="post" action="#">
<br><br><br><br>
	<h1>UPDATE FOOD</h1><br>
	<input type="text" name="fid" class="form-control rounded-0" style="font-family: Comic Sans MS;width:500px;"value="<?php echo $row['food_id'];?>" readonly><br>
		<input type="text" name="fname" class="form-control rounded-0" style="font-family: Comic Sans MS;width:500px; " value="<?php echo $row['food_name'];?>"><br>
		<input type="text" name="fowner" class="form-control rounded-0" style="font-family: Comic Sans MS;width:500px;"value="<?php echo $row['food_ownername'];?>"><br>
		<input type="submit" name="update" value="update" style="background-color:#f3f3f3;width:300px;">
		<a href="view.php">view food</a>
	</form><br><br><br>
</body>
</html>
<?php
include('conn.php');
if (isset($_POST['update'])) {
	$fid=$_POST['fid'];
	$fname=$_POST['fname'];
	$fowner=$_POST['fowner'];
	$update=mysqli_query($conn,"UPDATE food set food_name='$fname',food_ownername='$fowner' where food_id='$fid'");
	if ($update) {
		echo "updated";
		header('location:view.php');
	}
	else{
		echo"not updated".$conn->error;
	}
}
?>