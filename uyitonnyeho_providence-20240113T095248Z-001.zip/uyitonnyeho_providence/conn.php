<?php
$conn=new mysqli("localhost","root","","nkundimana") or die("failed");
?>