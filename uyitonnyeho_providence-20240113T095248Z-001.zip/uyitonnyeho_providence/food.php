<?php
session_start();
if(isset($_SESSION['user']))
{
}else
{
	header("location:home.php");
}
?>
<?php
$use=$_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;width: 1200px;height: 500px;">
welcome<?php echo $use?>
<div class="well shadow sm-4 bg-dark rounded-0" style="background-color: #28a745;float: left;width: 300px;height: 500px;"><br><br>
<a href="home.php" class="btn btn-outline-dark rounded-0" style="color: white;width: 300px;font-family: Comic Sans MS;">Home</a>
<a href="food.php" class="btn btn-outline-dark rounded-0" style="color: white;width: 300px;font-family: Comic Sans MS;">Add Food</a>
<a href="report.php" class="btn btn-outline-dark rounded-0" style="color: white;width: 300px;font-family: Comic Sans MS;">Report</a>
<form method="POST" action="logout.php" class="form-group">
	<button type="submit" name="logout" class="btn btn-outline-dark" style="color: white;font-family: Comic Sans MS;">Logout</button></form>
</div><br><br><BR>
<form method="POST" action="" class="form-group" style="width: 500px;">
<h1>ADD FOOD</h1><BR>
	<input type="number" name="fid" class="form-control rounded-0" placeholder="enter foodid" 
	style="font-family: Comic Sans MS;"><br>
	<input type="text" name="fname" class="form-control rounded-0" 
	placeholder="enter foodname" style="font-family: Comic Sans MS;"><br>
	<input type="text" name="fowner" class="form-control rounded-0" 
	placeholder="enter foodownername" style="font-family: Comic Sans MS;"><br>
	<button type="submit" name="record" class="btn btn-outline-dark rounded-0" style="color: back;width: 500px;font-family: Comic Sans MS;">Record Food</button>
	<a href="des.php" style="float: left;color: back;">Back</a><br><br>
	<a href="view.php" style="float: left;color: back;">View Food</a>
</form>
</div>
</body>
</html>
<?php
include('conn.php');
if (isset($_POST['record'])) {
	$fid=$_POST['fid'];
	$fname=$_POST['fname'];
	$fowner=$_POST['fowner'];
	$insert=mysqli_query($conn,"INSERT INTO food VALUES('$fid','$fname','$fowner')");
	if ($insert) {
		echo'<script>alert("inserted very well")</script>'.$conn->error;
	}
	else{
		echo'<script>alert("not inserted very well")</script>';
	}
}
?>
</div><br><br>
	<div class="footer">
<p style="color:white;">copy&copyright 2021</p>
</div>