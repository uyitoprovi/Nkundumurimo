
<?php
session_start();
if(isset($_SESSION['user']))
{
}else
{
	header("location:import.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<?php
include('conn.php');
$id=$_GET['id'];
$selectt=mysqli_query($conn,"select * from import where food_id='$id'");
$rw=mysqli_fetch_array($selectt);
?>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;width: 1200px;height: 500px;">
<div class="well shadow sm-4 bg-dark rounded-0" style="background-color: #28a745;float: left;width: 300px;height: 500px;"><br><br>
<a href="home.php" class="btn btn-outline-dark rounded-0" style="color: white;width: 300px;font-family: Comic Sans MS;">Home</a>
<a href="food.php" class="btn btn-outline-dark rounded-0" style="color: white;width: 300px;font-family: Comic Sans MS;">Add Food</a>
<a href="report.php" class="btn btn-outline-dark rounded-0" style="color: white;width: 300px;font-family: Comic Sans MS;">Report</a>
<form method="POST" action="logout.php" class="form-group">
	<button type="submit" name="logout" class="btn btn-outline-dark" style="color: white;font-family: Comic Sans MS;">Logout</button></form>
</div><br><br><BR>
<form method="POST" action="" class="form-group" style="width: 500px;">
<h1>EXPORT RECORD</h1><BR>
	<input type="number" name="id" class="form-control rounded-0" placeholder="enter foodid" 
	style="font-family: Comic Sans MS;" value="<?php echo $id?>"><br>
	<input type="text" name="quantity" class="form-control rounded-0" 
	placeholder="enter quantity" style="font-family: Comic Sans MS;"value="<?php echo $rw['quantity']?>"><br>
	<input type="text" name="quantity1" class="form-control rounded-0" 
	placeholder="enter quantity" style="font-family: Comic Sans MS;"><br>
	<button type="submit" name="export" class="btn btn-outline-dark rounded-0" style="color: back;width: 500px;font-family: Comic Sans MS;">EXPORT</button>
	<a href="viewimport.php" style="float: left;color: back;">Back</a><br><br>
	<a href="viewexport.php" style="float: left;color: back;">View export</a>
</form>
</div>
</body>
</html>


<?php
include('conn.php');
if (isset($_POST['export'])) {
	$ffid=$_POST['id'];
	$date=date('y/m/d');
	$quan=$_POST['quantity1'];
$select=mysqli_query($conn,"SELECT * from import where food_id='$ffid'");
while ($r=mysqli_fetch_array($select)){
	$fid=$r['food_id'];
	$quantity=$r['quantity'];
// 	if ($quantity<=0) {
// 		echo "not allowed";
// 	}
// 	else{
// $update=mysqli_query($conn,"UPDATE import set quantity=quantity-'$quan' where food_id='$ffid'");
// if($update){
// $insert=mysqli_query($conn,"INSERT into export values('','$ffid','$date','$quan')");
// if ($insert) {
// 	echo"done";
// }
// else{
// 	echo"not done";
// 	}
// 			}
// }
// }
// }
	if ($quan>$quantity) {
		echo'<script>alert("nothing done")</script>';

	}
	elseif ($quantity>$quan) {
		$update=mysqli_query($conn,"UPDATE import set quantity=quantity-'$quan' where food_id='$ffid'");
		if($update){
$insert=mysqli_query($conn,"INSERT into export values('','$ffid','$date','$quan')");
if ($insert) {
	echo'<script>alert("inserted")</script>';
}
else{
	echo"not inserted";
	}
	}
}
	else{
		header('location:viewimport.php');
}
}
}
?>
</div><br><br>
	<div class="footer">
<p style="color:white;">copy&copyright 2021</p>
</div>