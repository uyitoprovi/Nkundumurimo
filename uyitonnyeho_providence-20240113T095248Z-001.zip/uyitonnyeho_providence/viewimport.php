<?php
session_start();
if(isset($_SESSION['user']))
{
}else
{
	header("location:home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet"  href="css/bootstrap.min">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
</head>
<body class="bg-dark"><br><br><br>
<center><div class="well shadow sm-4 bg-light rounded-2" style="background-color: white;color:black;width: 1200px;height: auto;float:right;">
<form method="POST" action="logout.php" class="form-group">
	<button type="submit" name="logout" class="btn btn-outline-dark" style="color:back;font-family: Comic Sans MS;">Logout</button></form>
<br><H1>IMPORT STATUS</H1>
<br><table class="table table-stripped table-bordered" style="width:80%;">
	<tr>
	<th>emportid</th>
	<th>foodid</th>
	<th>foodname</th>
	<th>importdate</th>
	<th>quantity</th>
</tr>
<?php
include('conn.php');
$select=mysqli_query($conn,"SELECT * from import inner join food on import.food_id=food.food_id");
while ($row=mysqli_fetch_array($select)) {
	echo "<tr>
	<td>".$row['importid']."</td>
	<td>".$row['food_id']."</td>
	<td>".$row['food_name']."</td>
	<td>".$row['importdate']."</td>
	<td>".$row['quantity']."</td>
	<td><a href=\"export.php?id=".$row['food_id']."\">export</a></td>
	</tr>";
}
?>
</table><br>
<a href="report.php" style="float:left;margin-left:20%;"><button style="width:200px;height:8%;">report</button></a>
<a href="view.php" style="float:left;margin-left:10%;">back</a><br>
	</div><br><br><br><br><br><br>
	<div class="footer"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<p style="color:white;">copy&copyright 2021</p>
</div>
	</div>
	</center>