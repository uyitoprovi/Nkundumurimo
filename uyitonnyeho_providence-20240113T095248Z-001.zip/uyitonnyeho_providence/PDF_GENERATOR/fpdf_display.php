<?php
$conn = mysqli_connect("localhost","root","","javadatabase") or die("unable to connect");
$sql ="SELECT * from table1";
$result = mysqli_query($conn,$sql);
// while ($row = mysqli_fetch_array($result)) {
// 	$output .='
// 	<tr>
// 	<td>'.$row['name'] .'</td>
// 	<td>'.$row['address'] .'</td>
// 	 </tr>';
// }

require("fpdf/fpdf.php");
$pdf = new FPDF('p','mm','A4');
$pdf -> AddPage();
$pdf -> SetFont('Arial','B',14);
$pdf->cell(40, 10, "Name", 1, 0, 'C');
$pdf->cell(40, 10, "Address", 1, 0, 'C');
$pdf->SetFont('Arial','',14);
while ($row = mysqli_fetch_array($result)) {
	$pdf->cell(40, 10, $row['name'], 1, 0, 'C' );
	$pdf->cell(40, 10, $row['address'], 1, 1, 'C' );
	// echo "<br>";
	

}

$pdf->OutPut();

?>