<!DOCTYPE html>
<html>
<head>
	<title>REGISTER EMPLOYEE</title>
</head>
<body>
<form action="insert_record.php" method="POST" align="center"><br/><br/>
	Employee Name:<input type="text" name="emp_name" ><br/><br/>
	Employee Salary: <input type="number" name="emp_salary"><br/><br/>
	Employee Age:<input type="number" name="emp_age"><br/><br/>
	Date :<input type="date" name="date"><br/><br/><br/>

	<input type="submit" name="record" value="Register New Employee">


</form>
</body>
</html>