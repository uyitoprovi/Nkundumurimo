-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2021 at 05:36 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test1`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL COMMENT 'primary key',
  `employee_name` varchar(255) NOT NULL COMMENT 'employee name',
  `employee_salary` double NOT NULL COMMENT 'employee salary',
  `employee_age` int(11) NOT NULL COMMENT 'employee age',
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='datatable demo table';

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `employee_name`, `employee_salary`, `employee_age`, `Date`) VALUES
(1, 'Tiger Nixon', 320800, 61, NULL),
(2, 'Garrett Winters', 170750, 63, NULL),
(3, 'Ashton Cox', 86000, 66, NULL),
(4, 'Cedric Kelly', 433060, 22, NULL),
(5, 'Airi Satou', 162700, 33, NULL),
(6, 'Brielle Williamson', 372000, 61, NULL),
(7, 'Herrod Chandler', 137500, 59, NULL),
(8, 'Rhona Davidson', 327900, 55, NULL),
(9, 'Colleen Hurst', 205500, 39, NULL),
(10, 'Sonya Frost', 103600, 23, NULL),
(11, 'Jena Gaines', 90560, 30, NULL),
(12, 'Quinn Flynn', 342000, 22, NULL),
(13, 'Charde Marshall', 470600, 36, NULL),
(14, 'Haley Kennedy', 313500, 43, NULL),
(15, 'Tatyana Fitzpatrick', 385750, 19, NULL),
(16, 'Michael Silva', 198500, 66, NULL),
(65, 'jean', 20000, 23, '0000-00-00'),
(66, 'kamana', 20000, 23, '0000-00-00'),
(69, 'byusa de poles', 200000, 19, '2021-05-19'),
(70, 'UWIMANA', 3000, 20, '2021-05-19'),
(71, 'UWIMANA JEAN', 20000, 10, '2021-05-19'),
(72, 'UWINEZA Clarisse', 20000, 10, '2021-05-05'),
(73, 'UWIMANA J pierre', 20000, 10, '2021-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `expired`
--

CREATE TABLE `expired` (
  `employee_name` varchar(30) DEFAULT NULL,
  `TimeReceived` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expired`
--

INSERT INTO `expired` (`employee_name`, `TimeReceived`) VALUES
('Kwizera', '0000-00-00'),
('Kwizera', '2021-05-18'),
('Kwizera', '2021-05-18'),
('Kwizera', '2021-05-18'),
('', '0000-00-00'),
('kamana', '2021-05-18');

-- --------------------------------------------------------

--
-- Table structure for table `table1`
--

CREATE TABLE `table1` (
  `StudentName` varchar(50) DEFAULT NULL,
  `ass1` int(4) DEFAULT NULL,
  `ass2` float DEFAULT NULL,
  `ass3` float DEFAULT NULL,
  `ass4` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key', AUTO_INCREMENT=74;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
