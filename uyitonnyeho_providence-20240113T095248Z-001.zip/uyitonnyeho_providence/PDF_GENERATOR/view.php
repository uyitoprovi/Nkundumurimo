<?php
include('connect.php');
if (isset($_POST['display'])) {

$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

$select = "SELECT * from employee where Date between '$start_date' AND '$end_date'";
$result1 = mysqli_query($conn,$select);
echo '<table border="1"><tr><th>ID</th><th>Employee Name</th><th>Employee Salary</th><th>AGE</th><th>Date</th>';

while ($row1 = mysqli_fetch_array($result1)) {
	echo '<tr>
	<td>' .$row1['id'] .'</td>
	<td>' .$row1['employee_name'] .'</td>
	<td>' .$row1['employee_salary'] .'</td>
	<td>' .$row1['employee_age'] .'</td>
	<td>' .$row1['Date'] .'</td>
	</tr>
	';
	
}

}


?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="generatepdf.php" method="POST">
	<input type="date" name="start_date" value="<?php echo $start_date?>" readonly>
	<input type="date" name="end_date" value="<?php echo $end_date?>" readonly>
	<input type="submit" name="generatepdf" value="Generate PDF Report">
</form>
<!-- <a href="generatepdf.php"><button>Generate PDF Report</button></a> -->
</body>
</html>