<!DOCTYPE html>
<html>
<head>
	<title>View Records</title>
</head>
<body>
<form action="view.php" method="POST">
	<label>Start date</label><input type="date" name="start_date">
	<label>End date</label><input type="date" name="end_date">

	<input type="submit" name="display" value="View custom Report">


</form>
</body>
</html>