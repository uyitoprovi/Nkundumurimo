<?php
include('connect.php');
if (isset($_POST['record'])) {
	$emp_name = $_POST['emp_name'];
	$emp_salary = $_POST['emp_salary'];
	$emp_age = $_POST['emp_age'];
	$date = $_POST['date'];

$insert = "INSERT into employee values(null,'$emp_name','$emp_salary','$emp_age','$date')";
$result = mysqli_query($conn,$insert);
if ($insert) {
	// echo "done!";
	echo '<script>
	alert("well Recorded");
	window.location.href="record_data.php";

	</script>';
}
}



?>