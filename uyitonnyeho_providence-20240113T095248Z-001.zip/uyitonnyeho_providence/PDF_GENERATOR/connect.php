<?php
$conn = mysqli_connect("localhost","root","","test1") or die("unable to connect");




?>