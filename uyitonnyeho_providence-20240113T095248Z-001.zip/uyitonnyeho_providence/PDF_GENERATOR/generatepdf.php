<?php
// include('connect.php');
// include('view.php');
include('connect.php');
if (isset($_POST['generatepdf'])) {

$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

$select = "SELECT * from product where Date between '$start_date' AND '$end_date'";
$result1 = mysqli_query($conn,$select);

// $sql ="SELECT * from employee";
// $result = mysqli_query($conn,$sql);
// while ($row = mysqli_fetch_array($result)) {
// 	$output .='
// 	<tr>
// 	<td>'.$row['name'] .'</td>
// 	<td>'.$row['address'] .'</td>
// 	 </tr>';
// }

require("fpdf/fpdf.php");
$pdf = new FPDF('p','mm','A4');
$pdf -> AddPage();
$pdf -> SetFont('Arial','B',14);
$pdf->cell(30, 10, "id", 1, 0, 'C');
$pdf->cell(45, 10, "pname", 1, 0, 'C');
$pdf->cell(40, 10, "quantity", 1, 0, 'C');
$pdf->cell(30, 10, "date", 1, 0, 'C');
$pdf->SetFont('Arial','',14);
while ($row = mysqli_fetch_array($result1)) {
	$pdf->cell(30, 10, $row['id'], 1, 0, 'C' );
	$pdf->cell(45, 10, $row['pname'], 1, 0, 'C' );
	$pdf->cell(40, 10, $row['quantity'], 1, 0, 'C' );
	$pdf->cell(30, 10, $row['date'], 1, 0, 'C' );
	// echo "<br>";
	

}

$pdf->OutPut();
}

?>